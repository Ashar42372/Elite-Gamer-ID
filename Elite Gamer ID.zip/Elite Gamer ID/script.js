let kill = 0;
let match = 0;
let win = 0;
function animateValue(id, start, end) {
    let current = start;
    let increment = Math.ceil(end / 50);

    let timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            current = end;
            clearInterval(timer);
        }
        document.getElementById(id).innerText = current;
    }, 10);
}

animateValue("kills", 0, 10440);
animateValue("matches", 0, 3581);
animateValue("wins", 0, 1895);

function toggleMode() {
    document.body.classList.toggle("dark");
}
